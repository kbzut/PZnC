* Implement a faster multinomial draw function (Tim Hopper's suggestion)
* Revise hedge implementation to prevent numeric overflow
* Implement all algorithms in Matlab
* Make sure that all algorithms are implemented equivalently in all languages
* Implement an Expert type/class
* Implement Exp4
* Implement Thompson sampling under specific distributional assumptions?
